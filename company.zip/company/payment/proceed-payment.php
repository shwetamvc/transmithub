<?php

require_once  'payu.php';
require_once  'connect.php';

function payment_success() {
	/* Payment success logic goes here. */
	//echo "<pre>".print_r($_POST,true)."</pre>";
	if( $_POST['mihpayid'] != '' && $_POST['status'] == 'success' ) //payment succeded
	{
		if(check_amount($_POST['txnid'])){
		update_pay_status();
		echo "Congratulations !! The Payment is successful.";
		//header("Location: http://www.mavericktelecommunication.com/success");
		}else{
			echo "something went wrong . tampering attack.";
		}
	}else{
		echo "something went wrong";
	}
	
	
}

function payment_failure() {
	/* Payment failure logic goes here. */
	update_pay_status();
	echo "Payment fail";
	//header("Location: http://www.mavericktelecommunication.com/unsuccess");
}


   $txnid = uniqid(); 
//echo "<pre>".print_r($_POST)."</pre>";
	$amount 	= $_POST['amount'];
	$firstname 	= $_POST['firstname']; 
	$email 		= $_POST['email']; 
	$phone 		= $_POST['phone']; 
	$paymentoptions = $_POST['paymentoptions'];
	$productinfo 	= $_POST['productinfo'];
	$currency 	= $_POST['currency'];
	if( $_POST['pay_btn'] != ''  )
	{
		/*$google_recap = google_recaptcha();
		/*if( $google_recap != '1' ) 
		{
		
			echo "<font color='red'>Sorry wrong captcha code. Please try again. </font> <a href='http://www.mavericktelecommunication.com/payments'>Pay</a>";
		
			exit;
		}*/
	
	pay_page( array ('key' => '46nUnc', 
				'txnid' => "$txnid",
				'amount' => "$amount",
				'firstname' => "$firstname", 
				'email'=> "$email", 
				'phone' => "$phone", 
				'paymentoptions' => "$paymentoptions",
				'productinfo' => "$productinfo",
				'currency' => "$currency",
				'surl' => 'payment_success', 
				'furl' => 'payment_failure' ),
			'64GHa9Ug' );
	}
	save_pay($txnid);
//header("Location: http://www.mavericktelecommunication.com/success/");
//echo "hello";
?>