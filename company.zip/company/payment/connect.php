<?php
function connect()
{
	$con = mysql_connect("localhost","transmithub","H4rH4r+M4h4d3v");
	if (!$con)
	{
	die('Could not connect: ' . mysql_error());
	}
	mysql_select_db("transmit_transmit", $con);
	return $con;
} //End connect()

function save_pay()
{  
        
  	$sql = "INSERT INTO `transmit_transmit`.`payment` (
	`txnid`,
	`paymentoptions`, 
	`productinfo`, 
	`currency`, 
	`amount`, 
	`firstname`, 
	`email`, 
	`phone`,
	`ipaddrs`) 
	VALUES (
	'".mysql_escape_string ($_POST['txnid'])."',
	'".mysql_escape_string ($_POST['paymentoptions'])."', 
	'".mysql_escape_string ($_POST['productinfo'])."', 
	'".mysql_escape_string ($_POST['currency'])."', 
	'".mysql_escape_string ($_POST['amount'])."', 
	'".mysql_escape_string ($_POST['firstname'])."', 
	'".mysql_escape_string ($_POST['email'])."', 
	'".mysql_escape_string ($_POST['phone'])."',
	'".mysql_escape_string ($_SERVER['REMOTE_ADDR'])."'
	)";

	$con = connect();
	$msg = mysql_query($sql)?"successfully submited":die(mysql_error());
	mysql_close($con);
} //End save_pay()


function update_pay_status()
{
	//Array ( [mihpayid] => 403993715514809270 [mode] => CC [status] => success [unmappedstatus] => captured [key] => mD3s63 [txnid] => 57ac5dcb620ee [amount] => 10.00 [cardCategory] => domestic [discount] => 0.00 [net_amount_debit] => 10 [addedon] => 2016-08-11 16:43:19 [productinfo] => 1 [firstname] => a [lastname] => [address1] => [address2] => [city] => [state] => [country] => [zipcode] => [email] => a@a.com [phone] => 123456789 [udf1] => [udf2] => [udf3] => [udf4] => [udf5] => [udf6] => [udf7] => [udf8] => [udf9] => [udf10] => [hash] => b79bd270c473877be2cb529da2f8791a3a9d4ddd8928ffa3a3a8ee230acb8c29a0fecd14925fe634b448f254e80db72b3d5c31f1ec71d204c08f12ca620d00c2 [field1] => 62242276628 [field2] => 999999 [field3] => 907657431662241 [field4] => -1 [field5] => [field6] => [field7] => [field8] => [field9] => SUCCESS [payment_source] => payu [PG_TYPE] => HDFCPG [bank_ref_num] => 907657431662241 [bankcode] => CC [error] => E000 [error_Message] => No Error [name_on_card] => test [cardnum] => 512345XXXXXX2346 [cardhash] => This field is no longer supported in postback params. )
	
	//Exit because mihpayid should be preset always after payment: failed or success
	if ( !$_POST['mihpayid'] || !$_POST['status'] || !$_POST['txnid'] ) die('wrong update status call'); 
	
	$sql = "update `transmit_transmit`.`payment` set
	`status` = '".$_POST['status']."',
	`amount_real` = '".$_POST['amount']."',
	mihpayid = '".$_POST['mihpayid']."',
	mode = '".$_POST['mode']."',
	unmappedstatus = '".$_POST['unmappedstatus']."',
	`key` = '".$_POST['key']."',
	cardcategory = '".$_POST['cardcategory']."',
	discount = '".$_POST['discount']."',
	net_amount_debit = '".$_POST['net_amount_debit']."',
	addedon = '".$_POST['addedon']."',
	address1 = '".$_POST['address1']."',
	address2 = '".$_POST['address2']."',
	city = '".$_POST['city']."',
	state = '".$_POST['state']."',
	country = '".$_POST['country']."',
	zipcode = '".$_POST['zipcode']."',
	hash = '".$_POST['hash']."',
	payment_source = '".$_POST['payment_source']."',
	pg_type = '".$_POST['pg_type']."',
	bank_ref_num = '".$_POST['bank_ref_num']."',
	bankcode = '".$_POST['bankcode']."',
	error = '".$_POST['error']."',
	error_message = '".$_POST['error_message']."',
	name_on_card = '".$_POST['name_on_card']."',
	cardnum = '".$_POST['cardnum']."'	 
	where txnid= '".$_POST['txnid']."'";

	$con = connect();
	if(mysql_query($sql))
	{
	$msg= "successfully updated";
	}
	else
	{
	$msg="Error";
	}
	mysql_close($con);
} //End update_pay_status()

/*
@ function to call recapta api of google using post
*/
/*function google_recaptcha()
{
	$service_url = 'https://www.google.com/recaptcha/api/siteverify';
	$curl = curl_init($service_url);
	$curl_post_data = array(
	        'secret' => '6Leg_icTAAAAAMI7x0FRQowWMyq_v-q28jGWx0al',
	        'response' => $_POST['g-recaptcha-response']
	);

	curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($curl, CURLOPT_POST, true);
	curl_setopt($curl, CURLOPT_POSTFIELDS, $curl_post_data);
	$curl_response = curl_exec($curl);
	if ($curl_response === false) {
	    $info = curl_getinfo($curl);
	    curl_close($curl);
	    die('error occured during curl exec. Additioanl info: ' . var_export($info));
	}
	curl_close($curl);
	$decoded = json_decode($curl_response);

	if (isset($decoded->success) && $decoded->success != 1 ) {
	    return $decoded->error-codes;
	}
	return $decoded->success;
}*/
?>