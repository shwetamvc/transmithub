<html>
<head>
</head>
<body>
<form name="payform" method="POST" action="proceed-payment.php">
    <table width="100%" height="373" border="0" cellpadding="0" cellspacing="0">
      <tr id="row1" style="display: none;">
        <td height="80" class="style9" scope="col">
			<div class="image" id="1" style="background-color: red;"><img src="images/1.jpg" title="Credit Card" style="height: 80px; width: 230px;"/></div>
			<div class="image" id="2" style="background-color: yellow;"><img src="images/1.jpg" title="Credit Card" style="height: 80px; width: 230px;"/></div>
			<div class="image" id="3"style="background-color: green;"><img src="images/3.png" title="Credit Card" style="height: 80px; width: 200px;"/></div>
			<div class="image" id="4" style="background-color: blue;"></div>
		</td>
      </tr>
	  <tr>
        <td height="40" class="style9" scope="col">Payment Method </td>
      </tr>
      <tr>
        <td height="40" class="style7" ><select name="paymentoptions" size="0" class="a" id="select1" style="min-width:98%; height:80%;" onChange="setImage();" >
            <option value="0" />Select </option>
            <option value="1" selected="selected">Credit Cards</option>
			 <option value="2">Debit Cards</option>
			  <option value="3">PayPal</option>
        </select></td>
      </tr>
      <tr>
        <td height="40" class="style9">Select Services </td>
      </tr>
      <tr>
        <td height="40"><span class="style7">
          <select name="productinfo" size="0" class="a" id="select2" style="min-width:98%; height:80%;" >
            <option value="0" disabled="disabled" selected="selected">Select </option>
            <option value="1" selected="selected">SMS Services</option>
            <option value="2">Voice Solutions</option>
          </select>
        </span></td>
      </tr>
      <tr>
        <td height="40" class="style9">Currency</td>
      </tr>
      <tr>
        <td height="40"><span class="style7">
          <select name="currency" size="0" class="a" id="select3" style="min-width:98%; height:80%;" >
            <option value="0"  disabled="disabled" >Select </option>
            <option value="356" selected="selected">Indian Rupees</option>
            <option value="124">Canadian Dollar</option>
            <option value="344">Hong Kong Dollars</option>
            <option value="826">Pound Sterling</option>
            <option value="064">Bhutan National Bank</option>
            <option value="512">Rial Omani</option>
            <option value="634">QAR</option>
            <option value="784">AED</option>
            <option value="840">USD</option>
            <option value="756">CHF</option>
            <option value="100">PAK</option>
            <option value="702">SGD</option>
            <option value="978">EUR</option>
            <option value="036">AUD</option>
             </select>
              
        </span></td>
      </tr>
      <tr>
        <td height="40"><span class="style9">Enter Amount </span></td>
      </tr>
      <tr>
        <td height="40">
        <input name="amount" type="text" id="amount" value="10.00" style="min-width:98%; min-height:98%;" size="40" maxlength="40" placeholder="0.00"  required/></td>
      </tr>
       <tr>
        <td height="40"><span class="style9">Enter Name</span></td>
      </tr>
      <tr>
        <td height="40">
          <input name="firstname" type="text" id="firstname" value="a" style="min-width:98%; min-height:98%;" size="40" maxlength="40" placeholder="Your First Name"  required />
          <span class="style7"> </span></td>
      </tr>
      <tr>
        <td height="40"><span class="style9">Enter Email ID </span></td>
      </tr>
      <tr>
        <td height="40">
          <input name="email" type="text" id="email" value="a@a.com"  style="min-width:98%; min-height:98%;" size="40" maxlength="40" placeholder="Your Email ID" required/>
          <span class="style7"> </span></td>
      </tr>
      
      <tr>
        <td height="40"><span class="style9">Contact No. </span></td>
      </tr>
      <tr>
        <td height="40"><input name="phone" type="number" id="phone" value="123456789"  style="min-width:98%; min-height:98%;" size="40" maxlength="40" placeholder="Contact No." required/></td>
      </tr>
      <tr>
        <td height="40">
          <input name="pay_btn" type="submit" id="pay" value="Proceed to Payment" maxlength="40" style="min-height:30px"/>
        </td>
        
      </tr>
      
    </table>
    </form>
    </td>
    <td width="53%"><table width="55%" height="40%" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td height="32" scope="col"><li><a href="privacypolicy.html" class="style9">Privacy Policy </a></li></td>
      </tr>
      <tr>
        <td height="32"><li><a href="paymenttermsrefundpolicy.html" class="style9">Payment Terms &amp; Refund Policy</a></li></td>
      </tr>
      <tr>
        <td height="32"><li><a href="termscondition.html" class="style9">Terms &amp; condition</a></li></td>
      </tr>
      <tr>
        <td height="32"><li><a href="faq.html" class="style9">FAQ </a></li></td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
</html>
