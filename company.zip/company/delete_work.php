<?php
 
$link = mysqli_connect("localhost", "transmithub", "H4rH4r+M4h4d3v", "transmit_transmit");
 
 
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
 
$sql = "DELETE FROM d_contact WHERE email='".$_POST[email]."'";
if(mysqli_query($link, $sql)){
    
     	include"UnsubscribeCompleted.html";
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
 
mysqli_close($link);
?>