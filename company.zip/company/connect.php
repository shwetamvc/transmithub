<?php

   $f_name=$_POST["f_name"];
   $l_name=$_POST["l_name"];
  $email=$_POST["email"];
  $company=$_POST["company"];
  $pn=$_POST["pn"];
  $country=$_POST["country"];
  $company_type=$_POST["company_type"];
  $comments=$_POST["comments"];
   
  $con=mysql_connect("localhost","transmithub","H4rH4r+M4h4d3v");
  if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }
 mysql_select_db("transmit_transmit", $con);

  $insert_query= "INSERT INTO `transmit_transmit`.`d_contact` (`f_name`,`l_name`, `email`, `company`, `pn`, `country`, `company_type`, `comments`) VALUES ('".$f_name."','".$l_name."', '".$email."', '".$company."', '".$pn."', '".$country."', '".$company_type."', '".$comments."');";
 
 
  if(mysql_query($insert_query))
 {
   echo"<h1><center></center></h1>";
 }
 else
 {
   $msg= "Error";
 }
 
 
 mysql_close($con);
?>
<?php
 
$random_hash = md5(time());
//$file1 = "ebook.pdf";
//$file2 = "image.jpg";
$to =$_POST["email"];;
$subject = 'Transmithub';
$headers = 'From: [Transmithub].com' . "\r\n" .
  'Reply-To: [transmithub].com' . "\r\n" .
  'X-Mailer: PHP/' . phpversion() . "\r\n" .
  'Content-Type: multipart/mixed; boundary="PHP-mixed-'.$random_hash.'"';
//$attachment1 = chunk_split(base64_encode(file_get_contents($file1)));
//$attachment2 = chunk_split(base64_encode(file_get_contents($file2)));
 
$message = <<<EMAIL_MESSAGE
--PHP-mixed-$random_hash
Content-Type: text/html;Content-Type: text/css; charset="iso-8859-1"; boundary="PHP-alt-$random_hash
 <html>
<head>
	<title>mailer</title>
	<style type="text/css">
	*{margin: 0;padding: 0;}
		#main{height:auto;width:auto;background:rgb(122,054,6,.56);margin:auto 0px;}
	
 #footer{height: 100px;width: 800px;background:skyblue;margin:0px auto;border:2px solid black;}
h2{color: white;padding: 35px;margin:0px 35px;}
#content{width: auto;height:auto;color:black;border:2px solid black;margin:0px auto;}
p{padding:10px;margin:0px 35px;}
#main-content h3{color:blue;margin:0px 35px;}
@media screen and (max-width: 1028px) { 
h2{color: red;padding: 35px;}
#footer{height: 100px;width:auto;background: skyblue;margin:0px auto;border:2px solid black;}
}
@media screen and (min-width: 1030px) { 
h2{color: blue;padding: 35px;margin:0px 35px;}
#footer{height: 100px;width:auto;background: skyblue;margin:0px auto;border:2px solid black;}
}
@media screen and (max-width: 800px) { 
h2{color: green;padding:35px;margin:0px 35px;}
#footer{height: 100px;width:auto;background:skyblue;margin:0px auto;}
#content{width: auto;height:auto;color:black;border:2px solid black;margin:0px auto;}
}
@media screen and (max-width: 640px) { 
h2{color: green;padding:35px;margin:0px 35px;}
#footer{height: 100px;width:auto;background: skyblue;margin:0px auto;}
#content{width: auto;height: auto;color:black;border:2px solid black;margin:0px auto;}
}
	</style>


<link rel="stylesheet" type="text/css" href="">
</head>
<body>
<div id="main">
<div id="footer"><h2><center>Transmithub</center></h2></div>
<div id="content">
	<p>	Hello</p>
	<div id="main-content">
<h3>Thank you for contacting us!</h3>
</div>
<div>
<p>We have received your inquiry. One of our specialists will be in touch within one business day.</p><br>
<p>In the meantime, feel free to browse our download zone or blog to get more information on our services, or visit the Transmithub SMS API Developer Hub for comprehensive guides and documentation that will help you connect to our global messaging platform. For any questions or assistance, our Support Engineers are at your disposal on a 24/7 basis.</p>
</div>
<p>
Regards,<br>
Transmithub Team,</p>
</div>
<div id="footer">click here to<a href="http://www.transmithub.com/company/UnsubscribeRequest.html">Unsubscribe Emailer</a></div>
</div>
</body>
</html>

$attachment2
--PHP-mixed-$random_hash--
EMAIL_MESSAGE;
 
if(mail($to, $subject, $message, $headers))
	echo "<h1><center>Thank You For Contact...!</center></h1>";
else
	echo "Email sending failed";
?>